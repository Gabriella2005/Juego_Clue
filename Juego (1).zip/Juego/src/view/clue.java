package view;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class clue{
    public static void main(String[] args){
        JFrame ventana = new JFrame("juego");
        ventana.setVisible(true);
        ventana.setSize(500,500);
        ventana.setLocation(550, 200);
        ventana.setDefaultCloseOperation(3);

        
        
        JPanel panel = new JPanel();
        ventana.add(panel);
      
        
        JLabel titulo = new JLabel("Clue");
        titulo.setFont(new Font("Serif", Font.PLAIN, 40));
        titulo.setForeground(Color.red);
        titulo.setLocation(100, 100);
        panel.add(titulo);

        
        JButton info = new JButton("¿De qué trata?");
        info.setLocation(100,200);
        panel.add(info);
        
        
        ActionListener boton1 = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame ventana2 = new JFrame("ventana2");
                ventana2.setVisible(true);
                ventana2.setSize(800,500);
                ventana2.setLocation(550, 200);
                ventana2.setDefaultCloseOperation(3);
                
                JPanel panel2 = new JPanel();
                ventana2.add(panel2);
                
                JLabel desc = new JLabel("Bienvenido, a continuación jugarás clue. Pero esta es una versión modificada a mi manera");
                panel2.add(desc);
            }
        };
        info.addActionListener(boton1);
    }

}
